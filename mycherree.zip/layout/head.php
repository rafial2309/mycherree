        <meta charset="utf-8">
        <link href="dist/images/logo.svg" rel="shortcut icon">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Icewall admin is super flexible, powerful, clean & modern responsive tailwind admin template with unlimited possibilities.">
        <meta name="keywords" content="admin template, Icewall Admin Template, dashboard template, flat admin template, responsive admin template, web app">
        <meta name="author" content="LEFT4CODE">
        <title>MyCherree - Laundry & Dry Cleaning System</title>
        <!-- BEGIN: CSS Assets-->
        <link rel="stylesheet" href="dist/css/app.css" />
        <link rel="stylesheet" href="plugin/datatable/jquery.dataTables.min.css" />
        <style type="text/css">
            input[type=radio]
            {
              /* Double-sized Checkboxes */
              -ms-transform: scale(1.3); /* IE */
              -moz-transform: scale(1.3); /* FF */
              -webkit-transform: scale(1.3); /* Safari and Chrome */
              -o-transform: scale(1.3); /* Opera */
              transform: scale(1.3);
              padding: 10px;
              margin-right: 3px;
            }
        </style>
        <!-- END: CSS Assets-->