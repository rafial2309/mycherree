<script type="text/javascript" src="dist/js/app.js"></script>
<script type="text/javascript" src="plugin/datatable/jquery-3.5.1.js"></script>
<script type="text/javascript" src="plugin/datatable/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="plugin/datatable/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="plugin/datatable/buttons.flash.min.js"></script>
<script type="text/javascript" src="plugin/datatable/jszip.min.js"></script>
<script type="text/javascript" src="plugin/datatable/buttons.html5.min.js"></script>
<script type="text/javascript" src="plugin/mask/jquery.mask.min.js"></script>