<?php

$conn = mysqli_connect('jeeves-indonesia.com','jeevesin_myceri','Pantaipik2022!','jeevesin_myceri');

?>